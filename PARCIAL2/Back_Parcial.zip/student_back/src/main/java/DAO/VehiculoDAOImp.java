package DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import Model.vehiculo;

@Repository
public class VehiculoDAOImp implements VehiculoDAO {

    @Autowired
    private SessionFactory sessionFactory;

    public boolean registrarEntrada(vehiculo vehiculo) {
        boolean status = false;
        try {
            Session currentSession = sessionFactory.getCurrentSession();
            currentSession.save(vehiculo);
            status = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public List<vehiculo> obtenerVehiculosRegistrados() {
        Session currentSession = sessionFactory.getCurrentSession();
        Query<vehiculo> query = currentSession.createQuery("from Vehiculo", vehiculo.class);
        List<vehiculo> list = query.getResultList();
        return list;
    }

    public boolean eliminarEntrada(int vehiculo_id) {
        boolean status = false;
        try {
            Session currentSession = sessionFactory.getCurrentSession();
            vehiculo vehiculo = currentSession.get(vehiculo.class, vehiculo_id);
            if (vehiculo != null) {
                currentSession.delete(vehiculo);
                status = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public vehiculo obtenerDetalleVehiculo(int vehiculo_id) {
        Session currentSession = sessionFactory.getCurrentSession();
        vehiculo vehiculo = currentSession.get(vehiculo.class, vehiculo_id);
        return vehiculo;
    }

    public boolean actualizarEntrada(vehiculo vehiculo) {
        boolean status = false;
        try {
            Session currentSession = sessionFactory.getCurrentSession();
            currentSession.update(vehiculo);
            status = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}
