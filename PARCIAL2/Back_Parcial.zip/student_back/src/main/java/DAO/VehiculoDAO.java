package DAO;

import java.util.List;
import Model.vehiculo; 

public interface VehiculoDAO {

    boolean registrarEntrada(vehiculo vehiculo); 
    List<vehiculo> obtenerVehiculosRegistrados(); 
    boolean eliminarEntrada(int vehiculo_id); 
    vehiculo obtenerDetalleVehiculo(int vehiculo_id);
    boolean actualizarEntrada(vehiculo vehiculo);
	boolean savevehiculo(vehiculo vehiculo);
	List<vehiculo> getVehiculos();
	boolean deleteVehiculo(vehiculo vehiculo);
	List<vehiculo> getvehiculotByID(vehiculo vehiculo);
}
