package Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehiculo")
public class vehiculo {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int vehiculo_id;
	private String vehiculo_placa;
	private String vehiculo_entrada;
	private String vehiculo_salida;
	private String vehiculo_ubicacion;
	private String vehiculo_tipo;
	
	public int getvehiculo_id() {
		return vehiculo_id;
	}
	public void setVehiculo_id(int vehiculo_id) {
		this.vehiculo_id = vehiculo_id;
	}
	public String getvehiculo_placa() {
		return vehiculo_placa;
	}
	public void setStudent_name(String vehiculo_placa) {
		this.vehiculo_placa = vehiculo_placa;
	}
	public String getvehiculo_entrada() {
		return vehiculo_entrada;
	}
	public void setvehiculo_entrada(String vehiculo_entrada) {
		this.vehiculo_entrada = vehiculo_entrada;
	}
	public String getvehiculo_salida() {
		return vehiculo_salida;
	}
	public void setvehiculo_salida(String vehiculo_salida) {
		this.vehiculo_salida = vehiculo_salida;
	}
	
	public String getvehiculo_ubicacion() {
		return vehiculo_ubicacion;
	}
	public void setvehiculo_ubicacion(String vehiculo_ubicacion) {
		this.vehiculo_ubicacion = vehiculo_ubicacion;
	}
	public String getvehiculo_tipo() {
		return vehiculo_salida;
	}
	public void setvehiculo_tipo(String vehiculo_tipo) {
		this.vehiculo_tipo = vehiculo_tipo;
	}
	
}
