package Controller;

public class Model {

}
