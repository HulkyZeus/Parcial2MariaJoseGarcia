package Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Model.vehiculo; 
import Service.VehiculoService; 

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/api/parqueadero") 
public class ParqueaderoController { 

    @Autowired
    private VehiculoService vehiculoService; 

    @PostMapping("registrar-entrada") 
    public boolean registrarEntrada(@RequestBody vehiculo vehiculo) { 
        return vehiculoService.registrarEntrada(vehiculo); 
    }

    @GetMapping("vehiculos-registrados") 
    public List<vehiculo> obtenerVehiculosRegistrados() { 
        return vehiculoService.obtenerVehiculosRegistrados();
    }

    @DeleteMapping("eliminar-entrada/{vehiculo_id}") 
    public boolean eliminarEntrada(@PathVariable("vehiculo_id") int vehiculo_id) { 
        return vehiculoService.eliminarEntrada(vehiculo_id);
    }

    @GetMapping("detalle-vehiculo/{vehiculo_id}") 
    public vehiculo obtenerDetalleVehiculo(@PathVariable("vehiculo_id") int vehiculo_id) { 
        return vehiculoService.obtenerDetalleVehiculo(vehiculo_id); 
    }

    @PostMapping("actualizar-entrada/{vehiculo_id}") 
    public boolean actualizarEntrada(@RequestBody vehiculo vehiculo, @PathVariable("vehiculo_id") int vehiculo_id) {
        return vehiculoService.actualizarEntrada(vehiculo, vehiculo_id); 
    }
}
