package Service;

import java.util.List;
import Model.vehiculo;

public interface VehiculoService {

    boolean registrarEntrada(vehiculo vehiculo);

    List<vehiculo> obtenerVehiculosRegistrados();

    boolean eliminarEntrada(int vehiculo_id);

    vehiculo obtenerDetalleVehiculo(int vehiculo_id);

    boolean actualizarEntrada(vehiculo vehiculo, int vehiculo_id);

	boolean savevehiculo(vehiculo vehiculo);

	List<vehiculo> getVehiculos();

	boolean deleteVehiculo(vehiculo vehiculo);

	List<vehiculo> getvehiculoByID(vehiculo vehiculo);

	boolean updatevehiculo(vehiculo vehiculo);

	boolean actualizarEntrada1(vehiculo vehiculo, int vehiculo_id);

	boolean registrarEntrada1(vehiculo vehiculo);
}
