package Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import DAO.VehiculoDAO;
import Model.vehiculo;

@Service
@Transactional
public class Vehiculo_Service_Imp implements VehiculoService {

    @Autowired
    private VehiculoDAO vehiculoDAO;

    @Override
    public boolean registrarEntrada(vehiculo vehiculo) {
        return vehiculoDAO.registrarEntrada(vehiculo);
    }

    @Override
    public List<vehiculo> obtenerVehiculosRegistrados() {
        return vehiculoDAO.obtenerVehiculosRegistrados();
    }

    @Override
    public boolean eliminarEntrada(int vehiculo_id) {
        return vehiculoDAO.eliminarEntrada(vehiculo_id);
    }

    @Override
    public vehiculo obtenerDetalleVehiculo(int vehiculo_id) {
        return vehiculoDAO.obtenerDetalleVehiculo(vehiculo_id);
    }

    @Override
    public boolean actualizarEntrada1(vehiculo vehiculo, int vehiculo_id) {
        return vehiculoDAO.actualizarEntrada(vehiculo);
    }

	@Override
	public boolean registrarEntrada1(vehiculo vehiculo) {
		
		return false;
	}

	@Override
	public boolean actualizarEntrada(vehiculo vehiculo, int vehiculo_id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean savevehiculo(vehiculo vehiculo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<vehiculo> getVehiculos() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteVehiculo(vehiculo vehiculo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<vehiculo> getvehiculoByID(vehiculo vehiculo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updatevehiculo(vehiculo vehiculo) {
		// TODO Auto-generated method stub
		return false;
	}

  
}
